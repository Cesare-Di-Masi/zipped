﻿using MarksAndStudent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarksAndStudentLib
{
    public class PascalClass
    {
        private PascalStudent[] _studentList;

        PascalClass(PascalStudent[] studentsList) 
        {
            int nOfMarks = studentsList[0].Marks.Length;

            for (int i = 0; i < studentsList.Length; i++)
            {
                if (nOfMarks != studentsList[i].Marks.Length)
                    throw new ArgumentOutOfRangeException("the number of marks must be the same");
            }


            _studentList = studentsList;
        }

        public int numberOfNotAdmittedStudents()
        {
            int counter = 0;

            for (int i = 0; i < _studentList.Length; i++)
            {
                if (_studentList[i].scrutiny() == Result.NOTADMITTED)
                    counter++;
            }
            return counter;
        }

        public PascalStudent[] whichStudentsNotAdmitted()
        {
            PascalStudent[] list = new PascalStudent[numberOfNotAdmittedStudents()];
            int counter = 0;

            for(int i = 0;i < list.Length;i++)
            {
                if (_studentList[i].scrutiny() == Result.NOTADMITTED)
                {
                    list[counter] = _studentList[i];
                    counter++;
                }
            }
            return list;

        }

        public int numberOfAdmittedStudents()
        {
            int counter = 0;

            for (int i = 0; i < _studentList.Length; i++)
            {
                if (_studentList[i].scrutiny() == Result.ADMITTED)
                    counter++;
            }
            return counter;
        }

        public PascalStudent[] whichStudentsAdmitted()
        {
            PascalStudent[] list = new PascalStudent[numberOfNotAdmittedStudents()];
            int counter = 0;

            for (int i = 0; i < list.Length; i++)
            {
                if (_studentList[i].scrutiny() == Result.ADMITTED)
                {
                    list[counter] = _studentList[i];
                    counter++;
                }
            }
            return list;

        }
        public int numberOfSuspendedStudents()
        {
            int counter = 0;

            for (int i = 0; i < _studentList.Length; i++)
            {
                if (_studentList[i].scrutiny() == Result.SUSPENDED)
                    counter++;
            }
            return counter;
        }

        public PascalStudent[] whichStudentsSuspended()
        {
            PascalStudent[] list = new PascalStudent[numberOfNotAdmittedStudents()];
            int counter = 0;

            for (int i = 0; i < list.Length; i++)
            {
                if (_studentList[i].scrutiny() == Result.SUSPENDED)
                {
                    list[counter] = _studentList[i];
                    counter++;
                }
            }
            return list;

        }

        public int classAverage()
        {
            int average = 0;

            for(int i = 0; i< _studentList.Length;i++)
            {
                average += _studentList[i].calculateAverage();
            }
            return average;
        }

        public PascalStudent studentWithLowestAverage()
        {
            PascalStudent studentWithLowestAv = _studentList[0];
            int lowestAv = studentWithLowestAv.calculateAverage();
            int currentAv = 0;

            for (int i = 1; i < _studentList.Length; i++)
            {
                currentAv = _studentList[i].calculateAverage();

                if (lowestAv > currentAv)
                {
                    studentWithLowestAv = _studentList[i];
                    lowestAv = currentAv;

                }else if(lowestAv == currentAv)
                {

                    if(String.Compare(studentWithLowestAv.Surname, _studentList[i].Surname) == 1)
                    {
                        studentWithLowestAv = _studentList[i];
                        lowestAv = currentAv;

                    }else if(String.Compare(studentWithLowestAv.Surname, _studentList[i].Surname) == 0)
                    {

                        if(String.Compare(studentWithLowestAv.Name, _studentList[i].Name) == 1)
                        {
                            studentWithLowestAv = _studentList[i];
                            lowestAv = currentAv;
                        }

                    }

                }

            }

            return studentWithLowestAv;

        }

        public PascalStudent studentWithHighestAverage()
        {
            PascalStudent studentWithHighestAv = _studentList[0];
            int highestAv = studentWithHighestAv.calculateAverage();
            int currentAv = 0;

            for (int i = 1; i < _studentList.Length; i++)
            {
                currentAv = _studentList[i].calculateAverage();

                if (highestAv < currentAv)
                {
                    studentWithHighestAv = _studentList[i];
                    highestAv = currentAv;

                }
                else if (highestAv == currentAv)
                {

                    if (String.Compare(studentWithHighestAv.Surname, _studentList[i].Surname) == 1)
                    {
                        studentWithHighestAv = _studentList[i];
                        highestAv = currentAv;

                    }
                    else if (String.Compare(studentWithHighestAv.Surname, _studentList[i].Surname) == 0)
                    {

                        if (String.Compare(studentWithHighestAv.Name, _studentList[i].Name) == 1)
                        {
                            studentWithHighestAv = _studentList[i];
                            highestAv = currentAv;
                        }

                    }

                }

            }

            return studentWithHighestAv;

        }

        public int StudentsWithADeterminatedAverage(int wantedAverage)
        {
            if (wantedAverage < 1 || wantedAverage > 10)
                throw new ArgumentOutOfRangeException("illegal requested average");

            int counter = 0;

            for (int i = 0; i < _studentList.Length; i++)
            {
                if (_studentList[i].calculateAverage() == wantedAverage)
                    counter ++;
            }
            return counter;

        }


        public PascalStudent bestStudentOfASubject(int wantedMark)
        {
            int max = 0;

            for(int i = 0; i < _studentList.Length; i++)
            {
                if (max < _studentList[i].getMark(wantedMark - 1))
                    max = i;

            }
            return _studentList[max];
        }

    }
}
