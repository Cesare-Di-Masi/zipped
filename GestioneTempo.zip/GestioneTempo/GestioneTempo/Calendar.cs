﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace TimeManagement
{
    public class Calendar
    {
        private int _day,_month,_year;


        public int Year
        {
            get
            {
                return _year;
            }
            private set
            {
                if (value < 0)
                { throw new ArgumentOutOfRangeException("illegal year"); }
                _year = value;
            }
        }

        public int Month
        {
            get 
            {
                return _month;
            }
            private set
            {
                if (value < 1 || value > 12)
                { throw new ArgumentOutOfRangeException("illegal month"); }
                _month = value;
            }

        }
        public int Day 
        {
            get 
            {
                return _day;
            }
            private set
            {
                if (value < 0 || value > 365 || (value == 366 && Year % 4 != 0))
                { throw new ArgumentOutOfRangeException("illegal day"); }
                _day = value; 
            }
        }  

        //to do :spostare i controlli nelle proprietà
        public Calendar(int day, int month, int year)
        {
            Year = year;
            Month = month;
            Day = day; 
        }

        public bool isLeapYear()
        {
           return Year % 4 == 0;
        }

        public string returnMonthName(int monthNumber) 
        {
            if(monthNumber<0 || monthNumber > 12) { throw new ArgumentOutOfRangeException("illegal monthNumber"); }

            switch (monthNumber) 
            {
                case 1: return "January";
                case 2: return "February";
                case 3: return "March";
                case 4: return "April";
                case 5: return "May";
                case 6: return "June";
                case 7: return "July";
                case 8: return "August";
                case 9: return "September";
                case 10: return "October";
                case 11: return "November";
                default: return "December";
                break;
            }

        }


    }
}
