﻿namespace SwitchAndLamp;

class Program
{
    static void Main(string[] args)
    {

        try
        {
            Random rand = new Random();

            Lamp l1 = new Lamp();
            Lamp l2 = new Lamp();

        }
        catch (Exception ex) { }

    }
}
